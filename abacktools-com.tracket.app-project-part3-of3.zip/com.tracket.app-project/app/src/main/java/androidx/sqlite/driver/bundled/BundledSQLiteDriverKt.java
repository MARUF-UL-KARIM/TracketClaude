package androidx.sqlite.driver.bundled;

/* JADX INFO: compiled from: r8-map-id-0b7cfea85508d58686d8f3d90c16fee3cfa6bb72c3441c3c9e895e064ade750b */
/* JADX INFO: loaded from: classes.dex */
public final class BundledSQLiteDriverKt {
    private static final native long nativeOpen(String str, int i);

    private static final native int nativeThreadSafeMode();
}
